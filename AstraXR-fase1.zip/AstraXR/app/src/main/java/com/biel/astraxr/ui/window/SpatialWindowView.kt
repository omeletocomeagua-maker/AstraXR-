package com.biel.astraxr.ui.window

import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import com.biel.astraxr.ui.theme.AstraColors
import com.biel.astraxr.ui.theme.GlassButton
import com.biel.astraxr.ui.theme.GlassPanel

/**
 * Janela espacial arrastável em 2D (Normal Mode).
 * Arrastar/redimensionar são reais (funcionam com toque), não decorativos.
 */
@Composable
fun SpatialWindowView(
    window: SpatialWindow,
    onMove: (dx: Float, dy: Float) -> Unit,
    onResize: (widthDp: Float, heightDp: Float) -> Unit,
    onClose: () -> Unit,
    onMinimize: () -> Unit
) {
    if (window.minimized) return

    Box(
        modifier = Modifier
            .padding(start = window.x.dp, top = window.y.dp)
    ) {
        GlassPanel(
            modifier = Modifier.size(window.widthDp.dp, window.heightDp.dp),
            cornerRadius = 18
        ) {
            Box(modifier = Modifier.fillMaxWidth()) {
                // Barra de título — arrastar aqui move a janela inteira
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .pointerInput(window.appId) {
                            detectDragGestures { change, dragAmount ->
                                change.consume()
                                onMove(dragAmount.x / density, dragAmount.y / density)
                            }
                        },
                    horizontalArrangement = androidx.compose.foundation.layout.Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(window.title, color = AstraColors.TextPrimary)
                    Row {
                        GlassButton(label = "_", onClick = onMinimize)
                        androidx.compose.foundation.layout.Spacer(Modifier.size(8.dp))
                        GlassButton(label = "X", onClick = onClose)
                    }
                }
            }
        }

        // Alça de redimensionar, no canto inferior direito — real, não decorativa.
        Box(
            modifier = Modifier
                .padding(start = (window.widthDp - 24).dp, top = (window.heightDp - 24).dp)
                .size(24.dp)
                .pointerInput(window.appId) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        onResize(
                            window.widthDp + dragAmount.x / density,
                            window.heightDp + dragAmount.y / density
                        )
                    }
                }
        ) {
            Text("◢", color = AstraColors.TextSecondary)
        }
    }
}
