# AstraXR — Roadmap

Status: **Fase 1 entregue.** Fases seguintes serão construídas
incrementalmente, cada uma com código real e compilável, nunca mockup.

- [x] **Fase 1** — projeto Android, Home, AstraUI (Liquid Glass 2D),
      renderer 2D via Compose, input por toque, Spatial Window Manager
      2D, Spatial Memory (persistência local)
- [ ] **Fase 2** — VR Box Mode: stereo rendering (Left/Right Eye
      Camera), leitura de giroscópio/acelerômetro/magnetômetro,
      calibração de IPD/FOV/lens distance, troca de modo sem reiniciar
- [ ] **Fase 3** — Reality Camera (AR via ARCore com fallback para
      câmera simples), ambientes 360°/skyboxes
- [ ] **Fase 4** — Hand tracking (MediaPipe/ARCore), Gaze Tracking,
      Gaze + Hand Interaction, InteractionManager/GestureRecognizer
- [ ] **Fase 5** — Spatial Memory 3D (âncoras ARCore quando
      disponíveis), Smart Windows (colisão, "Organizar Espaço"),
      Spatial Profiles
- [ ] **Fase 6** — APK Installer (fluxo oficial do Android), Android
      Apps (listar apps instalados, abrir em janela quando o Android
      permitir)
- [ ] **Fase 7** — Astra Store (manifesto `app.json`, instalação,
      atualização, desinstalação)
- [ ] **Fase 8** — Browser interno, Player de vídeo (2D/180°/360°/SBS/TB),
      Modo Cinema
- [ ] **Fase 9** — Astra Performance Manager (perfis Balanced/
      Performance/Ultra Performance, degradação adaptativa)
- [ ] **Fase 10** — Sistema de plugins, acessibilidade, temas,
      polimento (blur real via RenderEffect em API 31+)

Cada fase, ao ser entregue, atualiza a seção "O que é real" do
`README.md` — nunca marcamos algo como pronto sem que o código exista
de fato.
