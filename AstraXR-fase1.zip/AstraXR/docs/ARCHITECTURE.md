# Arquitetura — Fase 1

Nesta fase o projeto é single-module (`app/`) por simplicidade e
confiabilidade de build. A separação em módulos (`core-ui`,
`core-window`, `core-render`, `core-input`, `core-spatial`,
`feature-*` etc., como descrito no pedido original) será introduzida
a partir da Fase 2/3, quando o número de subsistemas justificar o
custo de manter múltiplos módulos Gradle.

```
app/
  MainActivity.kt          — composição raiz, wiring de estado
  ui/theme/AstraUI.kt       — AstraColors, GlassCard, GlassButton, GlassPanel
  ui/home/HomeScreen.kt     — Home, AppGrid (placeholder)
  ui/window/
    SpatialWindow.kt        — modelo de dados da janela
    SpatialWindowManager.kt — estado + regras (abrir/mover/redimensionar/...)
    SpatialWindowView.kt    — composable arrastável/redimensionável
  data/SpatialMemoryStore.kt — persistência (DataStore + kotlinx.serialization)
  settings/DisplayMode.kt    — NORMAL / VR_BOX (stub) / AUTO (stub)
  diagnostics/AstraDiagnostics.kt — snapshot real de RAM/CPU
```

## Por que single-module agora

O documento original pede uma arquitetura modular completa desde o
início. Isso é válido para o produto final, mas criar 10+ módulos
Gradle vazios na Fase 1 não adiciona funcionalidade real — só
aumenta a superfície de erro de build sem motivo, já que ainda não
há separação de responsabilidades grande o suficiente para justificar
isolamento por módulo. A modularização será feita quando o Spatial
Interaction Engine (Fase 4) e o renderer estéreo (Fase 2) chegarem,
que é quando de fato existem fronteiras naturais entre subsistemas.
