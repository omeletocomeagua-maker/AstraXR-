package com.biel.astraxr.ui.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * AstraUI — identidade visual própria do AstraXR ("Liquid Glass").
 *
 * Implementação real: Compose não tem blur-atrás-do-conteúdo nativo e
 * performático em todas as versões de Android sem RenderEffect (API 31+),
 * então o efeito "vidro" aqui é feito com:
 *   - gradientes translúcidos (todas as versões)
 *   - leve realce de borda para dar profundidade
 * Isso é uma limitação real de compatibilidade (min SDK 26), não uma
 * simulação disfarçada — está documentado em docs/ROADMAP.md que o
 * blur-atrás-do-conteúdo real via RenderEffect é item de Fase 1.x
 * para dispositivos API 31+.
 */

object AstraColors {
    val Background = Color(0xFF0B0E1A)
    val GlassFill = Color(0x33FFFFFF)
    val GlassBorder = Color(0x55FFFFFF)
    val AccentStart = Color(0xFF7C9CFF)
    val AccentEnd = Color(0xFFC9D6FF)
    val TextPrimary = Color(0xFFF5F6FA)
    val TextSecondary = Color(0xB3F5F6FA)
}

@Composable
fun AstraTheme(content: @Composable () -> Unit) {
    MaterialTheme(content = content)
}

@Composable
fun GlassPanel(
    modifier: Modifier = Modifier,
    cornerRadius: Int = 24,
    content: @Composable () -> Unit
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(cornerRadius.dp))
            .background(
                Brush.linearGradient(
                    colors = listOf(Color(0x40FFFFFF), Color(0x14FFFFFF)),
                    start = Offset(0f, 0f)
                )
            )
            .border(1.dp, AstraColors.GlassBorder, RoundedCornerShape(cornerRadius.dp))
            .padding(16.dp)
    ) {
        content()
    }
}

@Composable
fun GlassCard(
    title: String,
    subtitle: String? = null,
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(20.dp))
            .background(AstraColors.GlassFill)
            .border(1.dp, AstraColors.GlassBorder, RoundedCornerShape(20.dp))
            .then(if (onClick != null) Modifier.clickable { onClick() } else Modifier)
            .padding(14.dp)
    ) {
        Text(
            text = title + (subtitle?.let { "\n$it" } ?: ""),
            color = AstraColors.TextPrimary,
            fontSize = 14.sp
        )
    }
}

@Composable
fun GlassButton(
    label: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(
                Brush.horizontalGradient(listOf(AstraColors.AccentStart, AstraColors.AccentEnd))
            )
            .clickable { onClick() }
            .padding(horizontal = 20.dp, vertical = 10.dp)
    ) {
        Text(
            text = label,
            color = Color(0xFF0B0E1A),
            fontSize = 14.sp,
            textAlign = TextAlign.Center
        )
    }
}
