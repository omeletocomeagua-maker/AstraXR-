package com.biel.astraxr.ui.home

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.biel.astraxr.ui.theme.AstraColors
import com.biel.astraxr.ui.theme.GlassCard

/**
 * Placeholder de app na grade da Home.
 *
 * Estes são apps FICTÍCIOS de exemplo (Browser, Vídeo, Configurações,
 * Diagnóstico). Não existe ainda leitura real dos apps instalados no
 * aparelho (item 26, "Android Apps") — isso é Fase 6. Abrir um destes
 * cards cria uma SpatialWindow real e funcional; o conteúdo dentro
 * dela hoje é só um placeholder de texto, exceto "Diagnóstico", que
 * mostra dados reais do aparelho.
 */
data class AstraApp(val id: String, val name: String)

val placeholderApps = listOf(
    AstraApp("browser", "Browser"),
    AstraApp("video", "Vídeo"),
    AstraApp("settings", "Configurações"),
    AstraApp("diagnostics", "Diagnóstico"),
)

@Composable
fun HomeScreen(
    onOpenApp: (AstraApp) -> Unit,
    onOpenDisplayModeSheet: () -> Unit
) {
    Column(modifier = Modifier.fillMaxSize().padding(24.dp)) {
        Text(
            "AstraXR",
            color = AstraColors.TextPrimary,
            fontSize = 26.sp
        )
        Text(
            "by Biel — Normal Mode",
            color = AstraColors.TextSecondary,
            fontSize = 13.sp
        )

        Box(modifier = Modifier.padding(top = 16.dp)) {
            com.biel.astraxr.ui.theme.GlassButton(label = "Display Mode", onClick = onOpenDisplayModeSheet)
        }

        LazyVerticalGrid(
            columns = GridCells.Fixed(3),
            contentPadding = PaddingValues(top = 24.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            items(placeholderApps) { app ->
                GlassCard(
                    title = app.name,
                    modifier = Modifier.fillMaxSize(),
                    onClick = { onOpenApp(app) }
                )
            }
        }
    }
}
