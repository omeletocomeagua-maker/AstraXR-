package com.biel.astraxr

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import com.biel.astraxr.diagnostics.AstraDiagnostics
import com.biel.astraxr.settings.DisplayMode
import com.biel.astraxr.ui.home.HomeScreen
import com.biel.astraxr.ui.theme.AstraColors
import com.biel.astraxr.ui.theme.AstraTheme
import com.biel.astraxr.ui.window.SpatialWindow
import com.biel.astraxr.ui.window.SpatialWindowManager
import com.biel.astraxr.ui.window.SpatialWindowView

class MainActivity : ComponentActivity() {

    private val windowManager: SpatialWindowManager by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AstraTheme {
                AstraXRRoot(windowManager)
            }
        }
    }
}

@Composable
private fun AstraXRRoot(windowManager: SpatialWindowManager) {
    val context = LocalContext.current
    var displayMode by remember { mutableStateOf(DisplayMode.NORMAL) }
    var showDisplayModeSheet by remember { mutableStateOf(false) }
    var showVrNotReady by remember { mutableStateOf(false) }
    val windowList: List<SpatialWindow> by windowManager.windows.collectAsState()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(AstraColors.Background)
    ) {
        when (displayMode) {
            DisplayMode.NORMAL, DisplayMode.AUTO -> {
                HomeScreen(
                    onOpenApp = { app ->
                        if (app.id == "diagnostics") {
                            val snap = AstraDiagnostics.snapshot(context)
                            windowManager.open(
                                appId = "diagnostics",
                                title = "Diagnóstico — RAM ${snap.appMemoryUsedMb}MB / " +
                                        "${snap.systemMemoryAvailableMb}MB livres " +
                                        "de ${snap.systemMemoryTotalMb}MB · CPU: ${snap.cpuCores} núcleos"
                            )
                        } else {
                            windowManager.open(app.id, app.name)
                        }
                    },
                    onOpenDisplayModeSheet = { showDisplayModeSheet = true }
                )

                for (window: SpatialWindow in windowList) {
                    SpatialWindowView(
                        window = window,
                        onMove = { dx, dy -> windowManager.move(window.appId, dx, dy) },
                        onResize = { w, h -> windowManager.resize(window.appId, w, h) },
                        onClose = { windowManager.close(window.appId) },
                        onMinimize = { windowManager.toggleMinimize(window.appId) }
                    )
                }
            }
            DisplayMode.VR_BOX -> {
                // Nunca chega aqui de fato nesta fase — ao selecionar VR Box
                // no seletor abaixo, mostramos o aviso e voltamos para NORMAL
                // em vez de entrar num modo estéreo falso.
            }
        }

        if (showDisplayModeSheet) {
            AlertDialog(
                onDismissRequest = { showDisplayModeSheet = false },
                title = { Text("Display Mode") },
                text = { Text("Normal Mode está ativo e funcional.\n\nVR Box Mode ainda não foi implementado nesta fase — rendering estéreo, IPD/FOV e calibração de lente chegam na Fase 2.") },
                confirmButton = {
                    TextButton(onClick = { showDisplayModeSheet = false }) {
                        Text("OK")
                    }
                },
                dismissButton = {
                    TextButton(onClick = {
                        showDisplayModeSheet = false
                        showVrNotReady = true
                    }) {
                        Text("Tentar VR Box mesmo assim")
                    }
                }
            )
        }

        if (showVrNotReady) {
            AlertDialog(
                onDismissRequest = { showVrNotReady = false },
                title = { Text("VR Box Mode indisponível") },
                text = { Text("Esse modo depende de stereo rendering (Left/Right Eye Camera) e calibração de lente, que ainda não foram construídos. Continua em Normal Mode.") },
                confirmButton = {
                    TextButton(onClick = { showVrNotReady = false }) { Text("Entendi") }
                }
            )
        }
    }
}
