# AstraXR — by Biel

Projeto Android open-source: transformar um smartphone Android em uma
interface espacial, com Normal Mode (uso no celular) e VR Box Mode
(headset estereoscópico) no mesmo APK.

Este repositório contém a **Fase 1** do roadmap completo (ver
`docs/ROADMAP.md`). É um projeto real, compilável, sem mockups — mas
é intencionalmente apenas o começo. VR estéreo, hand tracking, gaze
tracking, Store, browser real, player de vídeo etc. **ainda não
existem** neste código. Ver seção "O que é real" abaixo.

## Abrir no Android Studio

1. Instale Android Studio (Koala/2024.1 ou mais recente).
2. `File → Open` e selecione a pasta `AstraXR/`.
3. Deixe o Gradle sincronizar (baixa as dependências do Google Maven
   e Maven Central — precisa de internet na primeira vez).
4. Rode em um emulador ou aparelho físico com Android 8.0 (API 26) ou
   superior.

Se preferir linha de comando, gere o wrapper primeiro (`gradle
wrapper` com o Gradle 8.7 instalado localmente) — o `gradle-wrapper.properties`
já está configurado, só falta o `.jar` do wrapper, que o Android
Studio gera automaticamente ao abrir o projeto.

## Gerar APK

No Android Studio: `Build → Build Bundle(s)/APK(s) → Build APK(s)`.
O APK debug sai em `app/build/outputs/apk/debug/`.

## Compilar pelo celular, sem computador (GitHub Actions)

O projeto já inclui `.github/workflows/build-apk.yml`, que compila o
APK na nuvem (não precisa de Android Studio nem de SDK local).

1. Crie uma conta no GitHub (github.com), se ainda não tiver.
2. Crie um repositório novo (pode ser privado).
3. Suba a pasta `AstraXR/` para esse repositório. Do celular, o jeito
   mais simples é: instale um app de terminal com git (ex.: Termux no
   Android) e rode `git init`, `git add .`, `git commit`, `git remote
   add origin <url-do-repo>`, `git push`. Se tiver acesso a um
   computador por alguns minutos (biblioteca, lan house, um amigo),
   também dá pra fazer isso pela interface web do GitHub em "Add
   file → Upload files", arrastando a pasta inteira.
4. Assim que o push acontecer (ou pela aba "Actions" do repositório,
   botão "Run workflow"), o GitHub compila o APK automaticamente.
5. Quando o workflow terminar (ícone verde ✅), abra a execução em
   "Actions" e baixe o artefato **AstraXR-debug-apk** — é o `.apk`
   pronto para instalar no celular.

## O que é REAL nesta fase

- Projeto Android/Kotlin + Compose completo, Gradle configurado, sem
  dependências inventadas.
- **AstraUI**: `GlassCard`, `GlassButton`, `GlassPanel` — componentes
  visuais funcionais (o "vidro" é gradiente translúcido + borda, não
  blur-atrás-do-conteúdo real — ver limitação abaixo).
- **Home** com grade de apps (placeholder) e botão de Display Mode.
- **Spatial Window Manager em 2D**: abrir, mover (drag real por
  toque), redimensionar (alça real), minimizar, fechar janelas.
- **Spatial Memory**: posição/tamanho/estado das janelas persistem de
  verdade via DataStore — feche e reabra o app, as janelas voltam.
- **Astra Diagnostics**: RAM do app, RAM do sistema, núcleos de CPU —
  dados reais do aparelho via `ActivityManager`/`Debug`.
- **Display Mode**: Normal Mode 100% funcional.

## O que NÃO é real ainda (e por quê)

- **VR Box Mode / rendering estéreo**: ao selecionar, o app mostra um
  aviso explícito em vez de fingir. Precisa de duas câmeras de
  renderização (Left/Right Eye), distorção de lente e calibração de
  IPD/FOV — isso é Fase 2.
- **Blur real atrás do conteúdo**: `RenderEffect` de blur só existe a
  partir da API 31. Como o `minSdk` é 26 (para rodar em mais
  aparelhos), a Fase 1 usa gradiente translúcido. Um blur real
  condicional a API 31+ é item de polimento futuro.
- **Hand tracking / gaze tracking**: dependem de MediaPipe/ARCore e de
  processamento de câmera em tempo real — Fase 4.
- **Reality Camera / AR / ambientes 360°**: dependem de ARCore com
  fallback para câmera simples — Fase 3.
- **Android Apps (listar apps instalados) / APK Installer / Astra
  Store / Browser / Player de vídeo**: nenhuma dessas telas existe
  ainda. Os cards da Home hoje ("Browser", "Vídeo", "Configurações")
  são placeholders que abrem uma janela vazia com o nome — servem
  para testar o Spatial Window Manager, não são funcionalidades reais.
- **Performance Manager / perfis Balanced/Performance/Ultra**: não
  implementado.
- **Sistema de plugins**: não implementado.

## Dependências que exigem hardware/API específicos (mapeadas para o futuro)

- Hand tracking e gaze tracking de qualidade dependem de câmera
  frontal e GPU capaz de rodar um modelo de visão computacional em
  tempo real — em aparelhos fracos, o fallback será Gaze+Touch ou
  Hand+Gyro, como especificado no documento original.
- ARCore não está disponível em todos os aparelhos Android — todo
  recurso que depender dele terá fallback documentado no momento em
  que for implementado.

## Próximos passos

Ver `docs/ROADMAP.md`. Este projeto será estendido fase por fase em
conversas seguintes, sempre entregando código real e funcional para
cada fase, nunca simulação.

## Licença

MIT — ver `LICENSE`.
