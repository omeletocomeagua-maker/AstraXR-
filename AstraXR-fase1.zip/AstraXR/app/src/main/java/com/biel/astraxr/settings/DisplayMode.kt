package com.biel.astraxr.settings

/**
 * Modo de exibição do AstraXR.
 *
 * NORMAL: totalmente funcional nesta fase — single display, janelas 2D.
 * VR_BOX: AINDA NÃO IMPLEMENTADO. Rendering estéreo (Left/Right Eye
 *         Camera), distorção de lente e calibração de IPD/FOV são
 *         Fase 2 do roadmap. Selecionar essa opção agora mostra um
 *         aviso explícito em vez de fingir um modo estéreo que não existe.
 * AUTO:   depende de detecção de VR Box (magnetic trigger / NFC / gyro
 *         heurístico) que também é Fase 2. Hoje se comporta como NORMAL.
 */
enum class DisplayMode {
    NORMAL,
    VR_BOX,
    AUTO
}
