# Contribuindo com AstraXR

- Kotlin idiomático, Compose para UI.
- Nada de simular funcionalidade: se algo depende de hardware ou API
  indisponível, implemente o melhor fallback e documente a limitação
  no README, não finja que funciona.
- Toda nova feature deve compilar e ser testável manualmente — sem
  APIs inventadas.
- PRs devem atualizar `docs/ROADMAP.md` quando fecham um item de fase.
