package com.biel.astraxr.diagnostics

import android.app.ActivityManager
import android.content.Context
import android.os.Debug

/**
 * Astra Diagnostics — Fase 1.
 *
 * Reporta apenas o que dá para medir de verdade nesta fase sem
 * hardware/API adicional: RAM do app e do sistema, núcleos de CPU
 * disponíveis. FPS real de composição de UI, GPU, temperatura,
 * giroscópio/acelerômetro/magnetômetro e status de ARCore/hand
 * tracking/gaze tracking entram conforme cada subsistema for
 * implementado nas fases seguintes — não são inventados aqui.
 */
data class AstraDiagnosticsSnapshot(
    val appMemoryUsedMb: Long,
    val systemMemoryAvailableMb: Long,
    val systemMemoryTotalMb: Long,
    val lowMemory: Boolean,
    val cpuCores: Int
)

object AstraDiagnostics {

    fun snapshot(context: Context): AstraDiagnosticsSnapshot {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memInfo = ActivityManager.MemoryInfo()
        am.getMemoryInfo(memInfo)

        val runtimeInfo = Debug.MemoryInfo()
        Debug.getMemoryInfo(runtimeInfo)
        val appMemMb = runtimeInfo.totalPss / 1024L // totalPss is in KB

        return AstraDiagnosticsSnapshot(
            appMemoryUsedMb = appMemMb,
            systemMemoryAvailableMb = memInfo.availMem / (1024 * 1024),
            systemMemoryTotalMb = memInfo.totalMem / (1024 * 1024),
            lowMemory = memInfo.lowMemory,
            cpuCores = Runtime.getRuntime().availableProcessors()
        )
    }
}
