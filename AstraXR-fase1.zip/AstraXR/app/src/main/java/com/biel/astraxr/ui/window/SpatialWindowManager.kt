package com.biel.astraxr.ui.window

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.biel.astraxr.data.SpatialMemoryStore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * Spatial Window Manager — Fase 1 (2D / Normal Mode).
 *
 * Responsável por: criar, mover, redimensionar, minimizar, fixar e
 * fechar janelas, além de persistir e restaurar o layout via
 * Spatial Memory Engine.
 *
 * O que este arquivo NÃO faz ainda (por ser Fase 2+ e depender de
 * coisas que não existem no app hoje): colisão real entre janelas
 * (Smart Windows, item 16-18), sugestão automática de layout
 * ("Organizar Espaço", item 17), e qualquer coisa em 3D/estéreo.
 * As funções desses itens não foram criadas com corpo vazio fingindo
 * funcionar — simplesmente não existem ainda neste arquivo.
 */
class SpatialWindowManager(app: Application) : AndroidViewModel(app) {

    private val store = SpatialMemoryStore(app.applicationContext)

    private val _windows = MutableStateFlow<List<SpatialWindow>>(emptyList())
    val windows: StateFlow<List<SpatialWindow>> = _windows.asStateFlow()

    init {
        viewModelScope.launch {
            val restored = store.load()
            _windows.value = restored
        }
    }

    fun open(appId: String, title: String) {
        if (_windows.value.any { it.appId == appId && !it.minimized }) return
        val offset = _windows.value.size * 24f
        val window = SpatialWindow(
            appId = appId,
            title = title,
            x = 40f + offset,
            y = 40f + offset
        )
        _windows.value = _windows.value + window
        persist()
    }

    fun close(appId: String) {
        _windows.value = _windows.value.filterNot { it.appId == appId }
        persist()
    }

    fun move(appId: String, dx: Float, dy: Float) {
        _windows.value = _windows.value.map {
            if (it.appId == appId) it.copy(x = it.x + dx, y = it.y + dy) else it
        }
        persist()
    }

    fun resize(appId: String, widthDp: Float, heightDp: Float) {
        _windows.value = _windows.value.map {
            if (it.appId == appId) it.copy(
                widthDp = widthDp.coerceAtLeast(160f),
                heightDp = heightDp.coerceAtLeast(120f)
            ) else it
        }
        persist()
    }

    fun toggleMinimize(appId: String) {
        _windows.value = _windows.value.map {
            if (it.appId == appId) it.copy(minimized = !it.minimized) else it
        }
        persist()
    }

    fun togglePin(appId: String) {
        _windows.value = _windows.value.map {
            if (it.appId == appId) it.copy(pinned = !it.pinned) else it
        }
        persist()
    }

    private fun persist() {
        viewModelScope.launch {
            store.save(_windows.value)
        }
    }
}
