package com.biel.astraxr.ui.window

import kotlinx.serialization.Serializable

/**
 * Estado de uma janela espacial.
 *
 * Nesta fase (Normal Mode / 2D), x/y são posição em dp na tela.
 * z, rotationDeg e depth já existem no modelo porque serão usados
 * de verdade a partir da Fase 2 (Spatial Window Manager 3D / VR Box),
 * mas por enquanto ficam fixos em 0 — não há renderização 3D ainda,
 * então seria enganoso fingir que rotacionam ou têm profundidade real.
 */
@Serializable
data class SpatialWindow(
    val appId: String,
    val title: String,
    var x: Float,
    var y: Float,
    var z: Float = 0f,
    var rotationDeg: Float = 0f,
    var widthDp: Float = 260f,
    var heightDp: Float = 180f,
    var minimized: Boolean = false,
    var pinned: Boolean = false
)
