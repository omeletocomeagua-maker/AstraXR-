package com.biel.astraxr.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.biel.astraxr.ui.window.SpatialWindow
import kotlinx.coroutines.flow.first
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

private val Context.dataStore by preferencesDataStore(name = "astra_spatial_memory")
private val WINDOWS_KEY = stringPreferencesKey("windows_json")

/**
 * Spatial Memory Engine (Fase 1: escopo 2D).
 *
 * Persiste posição/tamanho/estado das janelas localmente com DataStore.
 * Isso é real e funciona offline, em qualquer aparelho, sem ARCore.
 *
 * Âncoras espaciais via ARCore (para persistência 3D no mundo real,
 * item 11 do seu documento) dependem de hardware compatível com
 * ARCore e de câmera — isso é Fase 3 (Reality Camera / AR) e terá
 * fallback automático para este armazenamento por coordenadas
 * relativas quando ARCore não estiver disponível, como você pediu.
 */
class SpatialMemoryStore(private val context: Context) {

    private val json = Json { ignoreUnknownKeys = true }

    suspend fun save(windows: List<SpatialWindow>) {
        val payload = json.encodeToString(windows)
        context.dataStore.edit { prefs ->
            prefs[WINDOWS_KEY] = payload
        }
    }

    suspend fun load(): List<SpatialWindow> {
        val prefs = context.dataStore.data.first()
        val raw = prefs[WINDOWS_KEY] ?: return emptyList()
        return try {
            json.decodeFromString(raw)
        } catch (e: Exception) {
            // Dado corrompido ou de versão anterior incompatível — não trava o app.
            emptyList()
        }
    }
}
